#ifndef __LCD_I2C_H
#define __LCD_I2C_H

#include "stm32f4xx_hal.h"  // BẮT BUỘC để có I2C_HandleTypeDef

// Thay đổi nếu địa chỉ I2C khác (thường là 0x27 hoặc 0x3F)
#define LCD_I2C_ADDR (0x27 << 1)

void lcd_init(I2C_HandleTypeDef *hi2c);
void lcd_send_string(char *str);
void lcd_send_cmd(char cmd);
void lcd_send_data(char data);
void lcd_put_cur(uint8_t row, uint8_t col);
void lcd_clear(void);

#endif
