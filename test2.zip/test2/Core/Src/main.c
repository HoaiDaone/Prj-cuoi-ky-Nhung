#include "main.h"
#include "lcd_i2c.h"

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_I2C1_Init(void);

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_I2C1_Init();

  lcd_init(&hi2c1);
  lcd_put_cur(0, 0);
  lcd_send_string("Hello STM32!");

  while (1)
  {
  }
}
